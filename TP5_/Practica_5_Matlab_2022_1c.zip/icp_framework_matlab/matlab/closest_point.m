%does closest-point matching between the point sets X and P.
%Input:  X, P.
%Output: P_matched, which you get by reordering the elements in P so
%        that they match the elements in X.
function P_matched=closest_point(X,P)
P_matched = P;
%Todo: implement.
end

